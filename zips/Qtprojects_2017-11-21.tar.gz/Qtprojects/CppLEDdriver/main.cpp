#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        cerr << "This program needs 2 arguments!" << endl;
        cerr << "  btled <pin#> <on/off>" << endl;
        return 1;
    }

    cout << "programname = " << argv[0] << endl;
    cout << "  arg1 = " << argv[1] << endl;
    cout << "  arg2 = " << argv[2] << endl;

    return 0;
}

